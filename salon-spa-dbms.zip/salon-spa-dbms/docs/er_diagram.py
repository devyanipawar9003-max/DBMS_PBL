"""Builds the ER diagram (docs/er_diagram.png / .svg) with Graphviz.
Notation: rectangles = entities (PK underlined, FK in italics), diamonds = relationships,
1 / N / M = cardinality, double line = total participation, double border = weak entity."""
import subprocess, sys, os

OUT = os.path.dirname(os.path.abspath(__file__))

ENT = {
    "CUSTOMER": ["<u>customer_id</u>", "first_name", "last_name", "phone (U)", "email (U)", "gender", "date_of_birth", "registered_on"],
    "SERVICE_CATEGORY": ["<u>category_id</u>", "category_name (U)", "description"],
    "SERVICE": ["<u>service_id</u>", "<i>category_id</i>", "<i>required_skill_id</i>", "service_name (U)", "duration_min", "price", "is_active"],
    "SKILL": ["<u>skill_id</u>", "skill_name (U)"],
    "STAFF": ["<u>staff_id</u>", "full_name", "phone (U)", "email (U)", "designation", "hire_date", "status"],
    "STAFF_SCHEDULE": ["<u>schedule_id</u>", "<i>staff_id</i>", "day_of_week", "shift_start", "shift_end"],
    "MEMBERSHIP_PLAN": ["<u>plan_id</u>", "plan_name (U)", "annual_fee", "discount_pct"],
    "PACKAGE": ["<u>package_id</u>", "package_name (U)", "price", "validity_days", "is_active"],
    "CUSTOMER_PACKAGE": ["<u>customer_package_id</u>", "<i>customer_id</i>", "<i>package_id</i>", "purchase_date", "expiry_date", "amount_paid", "status"],
    "APPOINTMENT": ["<u>appointment_id</u>", "<i>customer_id</i>", "appointment_date", "status", "booked_at", "notes"],
    "APPOINTMENT_SERVICE": ["<u>appt_service_id</u>", "<i>appointment_id</i>", "<i>service_id</i>", "<i>staff_id</i>", "start_time", "end_time", "price_charged", "<i>customer_package_id</i>"],
    "PRODUCT": ["<u>product_id</u>", "product_name (U)", "brand", "unit", "unit_cost", "stock_qty", "reorder_level"],
    "BILL": ["<u>bill_id</u>", "<i>appointment_id</i> (U)", "bill_date", "subtotal", "discount_amount", "tax_amount", "total_amount (derived)"],
    "PAYMENT": ["<u>payment_id</u>", "<i>bill_id</i>", "amount", "method", "paid_at", "reference_no"],
}
WEAK = {"STAFF_SCHEDULE", "APPOINTMENT_SERVICE", "PAYMENT"}

# (name, entity_a, card_a, total_a, entity_b, card_b, total_b, attributes)
REL = [
    ("BELONGS_TO", "SERVICE", "N", True, "SERVICE_CATEGORY", "1", False, []),
    ("REQUIRES", "SERVICE", "N", True, "SKILL", "1", False, []),
    ("HAS_SKILL", "STAFF", "M", False, "SKILL", "N", False, ["proficiency_level"]),
    ("WORKS_ON", "STAFF_SCHEDULE", "N", True, "STAFF", "1", False, []),
    ("BOOKS", "APPOINTMENT", "N", True, "CUSTOMER", "1", False, []),
    ("INCLUDES", "APPOINTMENT_SERVICE", "N", True, "APPOINTMENT", "1", True, []),
    ("FOR_SERVICE", "APPOINTMENT_SERVICE", "N", True, "SERVICE", "1", False, []),
    ("PERFORMED_BY", "APPOINTMENT_SERVICE", "N", True, "STAFF", "1", False, []),
    ("CONTAINS", "PACKAGE", "M", True, "SERVICE", "N", False, ["sessions_included"]),
    ("BUYS", "CUSTOMER_PACKAGE", "N", True, "CUSTOMER", "1", False, []),
    ("OF_PACKAGE", "CUSTOMER_PACKAGE", "N", True, "PACKAGE", "1", False, []),
    ("REDEEMS", "APPOINTMENT_SERVICE", "N", False, "CUSTOMER_PACKAGE", "1", False, []),
    ("SUBSCRIBES", "CUSTOMER", "M", False, "MEMBERSHIP_PLAN", "N", False, ["membership_id", "start_date", "end_date"]),
    ("USES_PRODUCT", "APPOINTMENT_SERVICE", "M", False, "PRODUCT", "N", False, ["usage_id", "quantity_used", "issued_at"]),
    ("BILLED_AS", "BILL", "1", True, "APPOINTMENT", "1", False, []),
    ("SETTLED_BY", "PAYMENT", "N", True, "BILL", "1", False, []),
]

C_ENT, C_HEAD, C_REL, C_WEAK = "#FBF3F7", "#9C3D6B", "#FFF8E6", "#F3E9F7"


def ent(name, attrs):
    weak = name in WEAK
    rows = "".join(f'<TR><TD ALIGN="LEFT" BALIGN="LEFT">{a}</TD></TR>' for a in attrs)
    border = 'BORDER="3" STYLE="ROUNDED"' if False else ""
    outer = f'<TABLE BORDER="{2 if weak else 1}" CELLBORDER="0" CELLSPACING="{2 if weak else 0}" CELLPADDING="3" BGCOLOR="{C_WEAK if weak else C_ENT}" COLOR="{C_HEAD}">'
    head = f'<TR><TD BGCOLOR="{C_HEAD}"><FONT COLOR="white"><B>{name}</B></FONT></TD></TR>'
    return f'  {name} [shape=plain label=<{outer}{head}{rows}</TABLE>>];'


lines = [
    "graph ER {",
    '  graph [layout=dot rankdir=LR splines=true overlap=false nodesep=0.35 ranksep=0.75 fontname="Helvetica" '
    'label=<<B>Salon &amp; Spa Appointment Management System – ER Diagram</B><BR/><FONT POINT-SIZE="10">'
    'Underlined = primary key · italic = foreign key · (U) = unique · double border = weak entity · '
    'double line = total participation</FONT>> labelloc=t fontsize=18 pad=0.3 dpi=170];',
    '  node [fontname="Helvetica" fontsize=10];',
    '  edge [fontname="Helvetica" fontsize=11 color="#5B4A52"];',
]
for n, a in ENT.items():
    lines.append(ent(n, a))
for (r, ea, ca, ta, eb, cb, tb, attrs) in REL:
    rid = f"r_{r}"
    weak_rel = ea in WEAK and r in ("WORKS_ON", "INCLUDES", "SETTLED_BY")
    lines.append(f'  {rid} [shape=diamond style="filled{",bold" if weak_rel else ""}" peripheries={2 if weak_rel else 1} '
                 f'fillcolor="{C_REL}" color="#B7791F" label="{r}" fontsize=9 width=1.4 height=0.6];')
    dbl = 'color="#5B4A52:invis:#5B4A52"'
    lines.append(f'  {ea} -- {rid} [label="{ca}" {dbl if ta else ""}];')
    lines.append(f'  {rid} -- {eb} [label="{cb}" {dbl if tb else ""}];')
    for i, at in enumerate(attrs):
        aid = f"a_{r}_{i}"
        lines.append(f'  {aid} [shape=ellipse label="{at}" fontsize=9 style=filled fillcolor="white" color="#B7791F" height=0.3];')
        lines.append(f'  {rid} -- {aid} [style=dashed len=0.6];')
lines.append("}")
dot = "\n".join(lines)
open(os.path.join(OUT, "er_diagram.dot"), "w").write(dot)
for fmt in ("png", "svg"):
    subprocess.run(["dot", f"-T{fmt}", os.path.join(OUT, "er_diagram.dot"), "-o", os.path.join(OUT, f"er_diagram.{fmt}")], check=True)
print("ok")
