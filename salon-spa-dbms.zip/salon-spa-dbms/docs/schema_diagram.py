"""Relational schema diagram (tables, PK, FK arrows) read live from MySQL information_schema."""
import subprocess, mysql.connector, os
OUT=os.path.dirname(os.path.abspath(__file__))
c=mysql.connector.connect(user=os.getenv("SALON_DB_USER","salon"),password=os.getenv("SALON_DB_PASSWORD","salon123"),database="salon_spa_db")
cur=c.cursor()
cur.execute("""SELECT table_name,column_name,column_key,data_type FROM information_schema.columns
 WHERE table_schema='salon_spa_db' AND table_name IN (SELECT table_name FROM information_schema.tables WHERE table_schema='salon_spa_db' AND table_type='BASE TABLE')
 ORDER BY table_name, ordinal_position""")
cols={}
for t,cn,k,dt in cur.fetchall(): cols.setdefault(t,[]).append((cn,k,dt))
cur.execute("""SELECT table_name,column_name,referenced_table_name FROM information_schema.key_column_usage
 WHERE table_schema='salon_spa_db' AND referenced_table_name IS NOT NULL""")
fks=cur.fetchall(); fkset={(t,cn) for t,cn,_ in fks}
L=['digraph S {','graph [rankdir=LR nodesep=0.3 ranksep=0.9 dpi=170 fontname="Helvetica" label=<<B>Relational Schema – salon_spa_db (18 tables)</B><BR/><FONT POINT-SIZE="10">PK = primary key · FK = foreign key · arrows point from FK to the referenced PK</FONT>> labelloc=t fontsize=18];','node [shape=plain fontname="Helvetica" fontsize=10]; edge [color="#9C3D6B" arrowsize=0.7];']
for t,cs in cols.items():
    rows=""
    for cn,k,dt in cs:
        tag=("PK " if k=="PRI" else "")+("FK" if (t,cn) in fkset else "")
        name=f"<B>{cn}</B>" if k=="PRI" else (f"<I>{cn}</I>" if (t,cn) in fkset else cn)
        rows+=f'<TR><TD ALIGN="LEFT" PORT="{cn}">{name}</TD><TD ALIGN="LEFT"><FONT COLOR="#7a6a72">{dt}</FONT></TD><TD>{("<FONT COLOR=\"#9C3D6B\">"+tag+"</FONT>") if tag else " "}</TD></TR>'
    L.append(f'{t} [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" COLOR="#9C3D6B" BGCOLOR="#FBF3F7"><TR><TD COLSPAN="3" BGCOLOR="#9C3D6B"><FONT COLOR="white"><B>{t}</B></FONT></TD></TR>{rows}</TABLE>>];')
for t,cn,rt in fks:
    rc=[x[0] for x in cols[rt] if x[1]=="PRI"][0]
    L.append(f'{t}:{cn} -> {rt}:{rc};')
L.append("}")
open(os.path.join(OUT,"schema_diagram.dot"),"w").write("\n".join(L))
for f in ("png","svg"): subprocess.run(["dot",f"-T{f}",os.path.join(OUT,"schema_diagram.dot"),"-o",os.path.join(OUT,f"schema_diagram.{f}")],check=True)
