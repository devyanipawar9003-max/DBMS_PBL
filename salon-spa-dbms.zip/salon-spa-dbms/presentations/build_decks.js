// Builds the three review decks for the DBMS PBL (Project 66).
// node build_decks.js   ->  Review1_*.pptx, Review2_*.pptx, Review3_*.pptx
const pptxgen = require("pptxgenjs");
const path = require("path");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");

const ROOT = path.resolve(__dirname, "..");
const IMG = (p) => path.join(ROOT, p);

const THEME = {
  name: "Glow and Grace",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: "2B1D24", lt1: "FFFFFF", dk2: "4A1832", lt2: "F7EEF3",
    accent1: "9C3D6B", accent2: "D98BB0", accent3: "B7791F", accent4: "5B4A52",
    accent5: "EBD7E1", accent6: "2E7D5B", hlink: "9C3D6B", folHlink: "6D2E46",
  },
};
const HEX = THEME.colors;
const META = {
  student: "Devyani Pawar", roll: "25WU0102069", section: "AIML Rhinos",
  course: "Database Management Systems (DBMS) · Project-Based Learning",
  uni: "School of Technology, Woxsen University",
  project: "Salon & Spa Appointment Management System",
};
const DIMS = require(path.join(ROOT, "screenshots/cropped/dims.json"));
function shot(pres, s, name, x, y, maxW, maxH) {
  const [w, h] = DIMS[name]; const r = Math.min(maxW / w, maxH / h);
  const W = w * r, H = h * r;
  s.addShape("rect", { x: x - 0.02, y: y - 0.02, w: W + 0.04, h: H + 0.04, fill: { color: "FFFFFF" }, line: { color: "D9C3CF", width: 0.75 } });
  s.addImage({ path: IMG("screenshots/cropped/" + name), x, y, w: W, h: H });
  return { W, H };
}
const FOOT = `DBMS PBL · Project 66 · ${META.student} (${META.roll})`;

function setup(pres, title) {
  pres.layout = "LAYOUT_16x9";
  pres.author = META.student;
  pres.company = "Woxsen University";
  pres.title = title;
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  const C = pres.SchemeColor;

  pres.defineSlideMaster({
    title: "TITLE_DARK",
    background: { color: HEX.dk2 },
    objects: [
      { placeholder: { options: { name: "kicker", type: "body", x: 0.6, y: 0.75, w: 8.8, h: 0.4, fontSize: 14, color: C.accent2, bold: true, charSpacing: 2 }, text: "" } },
      { placeholder: { options: { name: "title", type: "title", x: 0.6, y: 1.2, w: 8.8, h: 1.6, fontSize: 36, bold: true, color: C.background1, valign: "top", align: "left", fontFace: THEME.headFontFace }, text: "" } },
      { placeholder: { options: { name: "sub", type: "body", x: 0.6, y: 2.9, w: 8.8, h: 0.6, fontSize: 18, color: C.accent5 }, text: "" } },
      { placeholder: { options: { name: "meta", type: "body", x: 0.6, y: 3.9, w: 8.8, h: 1.2, fontSize: 13, color: C.background1, valign: "top" }, text: "" } },
    ],
  });
  pres.defineSlideMaster({
    title: "CONTENT",
    background: { color: "FFFFFF" },
    margin: [0.5, 0.5, 0.55, 0.5],
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.28, w: 9.0, h: 0.7, fontSize: 26, bold: true, color: C.text2, valign: "middle", align: "left", fontFace: THEME.headFontFace }, text: "" } },
      { text: { text: FOOT, options: { x: 0.5, y: 5.25, w: 7.5, h: 0.25, fontSize: 9, color: HEX.accent4, fontFace: "Calibri", isTextBox: true } } },
    ],
    slideNumber: { x: 9.0, y: 5.25, w: 0.5, h: 0.25, fontSize: 9, color: HEX.accent4, fontFace: "Calibri", align: "right" },
  });
  pres.defineSlideMaster({
    title: "CLOSING_DARK",
    background: { color: HEX.dk2 },
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: 0.6, y: 0.6, w: 8.8, h: 0.9, fontSize: 32, bold: true, color: C.background1, align: "left", fontFace: THEME.headFontFace }, text: "" } },
    ],
  });
  return C;
}

function titleSlide(pres, C, review, title, sub, notes) {
  const s = pres.addSlide({ masterName: "TITLE_DARK" });
  s.addText(review, { placeholder: "kicker" });
  s.addText(title, { placeholder: "title" });
  s.addText(sub, { placeholder: "sub" });
  s.addText([
    { text: `${META.student}  ·  ${META.roll}  ·  ${META.section}`, options: { bold: true, breakLine: true } },
    { text: META.course, options: { breakLine: true } },
    { text: META.uni },
  ], { placeholder: "meta" });
  // motif: three plum "appointment slots"
  for (let i = 0; i < 3; i++) {
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 7.35 + i * 0.75, y: 0.3, w: 0.6, h: 0.32, rectRadius: 0.08,
      fill: { color: i === 1 ? HEX.accent2 : HEX.accent1 }, line: { color: HEX.dk2, width: 0 }, objectName: `slot${i}` });
  }
  if (notes) s.addNotes(notes);
  return s;
}

function content(pres, title, notes) {
  const s = pres.addSlide({ masterName: "CONTENT" });
  s.addText(title, { placeholder: "title" });
  if (notes) s.addNotes(notes);
  return s;
}

function card(pres, s, x, y, w, h, fill) {
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.1,
    fill: { color: fill || HEX.lt2 }, line: { color: fill || HEX.lt2, width: 0 } });
}

function badge(pres, s, x, y, label, fill, size) {
  const d = size || 0.42;
  s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: fill || HEX.accent1 }, line: { color: fill || HEX.accent1, width: 0 } });
  s.addText(String(label), { x, y, w: d, h: d, align: "center", valign: "middle", fontSize: d > 0.45 ? 16 : 13, bold: true, color: "FFFFFF", margin: 0, isTextBox: true });
}

// grid of icon-cards: items = [{h, t}]
function cardGrid(pres, s, items, opts) {
  const cols = opts.cols, x0 = opts.x || 0.5, y0 = opts.y || 1.15, W = opts.w || 9.0, gap = 0.25;
  const rows = Math.ceil(items.length / cols);
  const H = opts.h || 3.9;
  const cw = (W - gap * (cols - 1)) / cols, ch = (H - gap * (rows - 1)) / rows;
  items.forEach((it, i) => {
    const x = x0 + (i % cols) * (cw + gap), y = y0 + Math.floor(i / cols) * (ch + gap);
    card(pres, s, x, y, cw, ch);
    badge(pres, s, x + 0.18, y + 0.18, it.n || i + 1, it.color);
    s.addText(it.h, { x: x + 0.72, y: y + 0.14, w: cw - 0.85, h: 0.5, fontSize: opts.hs || 15, bold: true, color: HEX.dk2, valign: "middle", margin: 0, isTextBox: true });
    s.addText(it.t, { x: x + 0.2, y: y + 0.72, w: cw - 0.4, h: ch - 0.85, fontSize: opts.ts || 13, color: HEX.dk1, valign: "top", margin: 0, isTextBox: true });
  });
}

function table(s, rows, opts) {
  const head = rows[0].map((t) => ({ text: t, options: { bold: true, color: "FFFFFF", fill: { color: HEX.accent1 } } }));
  const body = rows.slice(1).map((r, i) => r.map((t) => ({ text: String(t), options: { fill: { color: i % 2 ? "FFFFFF" : HEX.lt2 } } })));
  s.addTable([head, ...body], Object.assign({ x: 0.5, y: 1.15, w: 9.0, fontSize: 11, fontFace: "Calibri", color: HEX.dk1,
    border: { type: "solid", pt: 0.5, color: HEX.accent5 }, valign: "middle", margin: 0.05 }, opts));
}

function code(s, text, x, y, w, h, fs) {
  s.addShape("rect", { x, y, w, h, fill: { color: "2B1D24" }, line: { color: "2B1D24", width: 0 } });
  s.addText(text, { x: x + 0.15, y: y + 0.1, w: w - 0.3, h: h - 0.2, fontFace: "Courier New", fontSize: fs || 10, color: "F7EEF3", valign: "top", margin: 0, isTextBox: true });
}

function stat(s, x, y, w, big, label, color) {
  s.addText(big, { x, y, w, h: 0.75, fontSize: 36, bold: true, color: color || HEX.accent1, fontFace: "Cambria", margin: 0, isTextBox: true });
  s.addText(label, { x, y: y + 0.75, w, h: 0.5, fontSize: 12, color: HEX.accent4, margin: 0, valign: "top", isTextBox: true });
}

function closing(pres, title, lines, notes) {
  const s = pres.addSlide({ masterName: "CLOSING_DARK" });
  s.addText(title, { placeholder: "title" });
  s.addText(lines.map((l, i) => ({ text: l, options: { bullet: true, breakLine: i < lines.length - 1 } })),
    { x: 0.6, y: 1.6, w: 8.6, h: 3.2, fontSize: 16, color: "FFFFFF", paraSpaceAfter: 8, valign: "top", isTextBox: true });
  if (notes) s.addNotes(notes);
  return s;
}

const chartBase = () => ({
  catAxisLabelColor: HEX.accent4, valAxisLabelColor: HEX.accent4, catAxisLabelFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt",
  catAxisLabelFontSize: 10, valAxisLabelFontSize: 10, valGridLine: { color: "EBD7E1", size: 0.5 }, catGridLine: { style: "none" },
  dataLabelFontFace: "+mn-lt", dataLabelFontSize: 10, dataLabelColor: HEX.dk1, titleFontFace: "+mn-lt", titleColor: HEX.dk2, titleFontSize: 13,
});

// =====================================================================
// REVIEW 1
// =====================================================================
async function review1() {
  const pres = new pptxgen();
  const C = setup(pres, "Review 1 – Problem, Requirements and ER Design");
  pres.addSection({ title: "Introduction" });
  titleSlide(pres, C, "REVIEW 1  ·  WEEK 7", META.project, "Problem identification, requirements and conceptual (ER) design",
    "Introduce yourself and the project. Review 1 covers the problem, scope, users, functional requirements, the ER diagram and the first relational schema.");

  let s = content(pres, "Why manual appointment books fail",
    "Explain the real problem: the paper book cannot see conflicts, skills, package balances or dues. Every one of these becomes a business rule in the database.");
  const probs = [
    { h: "Double-booked staff", t: "Two clients written into the same stylist's slot; one waits or walks out." },
    { h: "Wrong person for the job", t: "A barber booked for a facial because the book does not know staff skills." },
    { h: "Lost package sessions", t: "Prepaid packages tracked on cards; sessions over-used or disputed." },
    { h: "Stock and money leakage", t: "Products used without record; part-payments forgotten at the counter." },
  ];
  cardGrid(pres, s, probs, { cols: 2, h: 3.0, y: 1.15 });
  s.addText("Goal: one database that knows customers, services, staff skills, schedules, packages, stock and money — and refuses invalid entries.",
    { x: 0.5, y: 4.4, w: 9, h: 0.6, fontSize: 14, italic: true, color: HEX.accent1, margin: 0, isTextBox: true });

  s = content(pres, "Objectives", "Five measurable objectives; each maps to a review deliverable.");
  const objs = [
    ["Design", "a normalised (3NF) relational database covering all 12 required entity areas"],
    ["Enforce", "5 core business rules inside MySQL: no staff overlap, skill match, package limits, valid times, payment limits"],
    ["Populate", "realistic sample data (600+ appointments, 40 customers, 10 staff) and 20+ report queries"],
    ["Develop", "a Python (Streamlit) application for booking, packages, products, billing, payments and reports"],
    ["Validate", "the system with positive and negative test cases and a recorded demonstration"],
  ];
  objs.forEach((o, i) => {
    const y = 1.15 + i * 0.78;
    badge(pres, s, 0.5, y + 0.08, i + 1);
    s.addText([{ text: o[0] + " ", options: { bold: true, color: HEX.accent1 } }, { text: o[1], options: { color: HEX.dk1 } }],
      { x: 1.1, y, w: 8.4, h: 0.6, fontSize: 15, valign: "middle", margin: 0, isTextBox: true });
  });

  s = content(pres, "Scope, assumptions and users", "In scope vs out of scope, and the four user roles.");
  card(pres, s, 0.5, 1.15, 4.35, 3.9);
  s.addText("Scope", { x: 0.7, y: 1.25, w: 4, h: 0.4, fontSize: 16, bold: true, color: HEX.dk2, margin: 0, isTextBox: true });
  s.addText([
    { text: "In: customers, services & categories, staff, skills, weekly schedules, appointments, packages, memberships, product usage, bills, payments, reports", options: { bullet: true, breakLine: true } },
    { text: "Out: online booking portal, payroll, supplier purchase orders, SMS reminders", options: { bullet: true, breakLine: true } },
    { text: "Assumptions: single branch; open 09:00–21:00; 18% GST; prices in INR; one bill per visit", options: { bullet: true } },
  ], { x: 0.7, y: 1.7, w: 4.0, h: 3.2, fontSize: 13, color: HEX.dk1, valign: "top", paraSpaceAfter: 6, margin: 0, isTextBox: true });
  const roles = [["Receptionist", "registers customers, books, bills, takes payments"], ["Salon manager", "staff, skills, schedules, packages, stock, reports"],
    ["Stylist / therapist", "performs services, issues products"], ["Customer", "indirect user — receives services, buys packages"]];
  roles.forEach((r, i) => {
    const y = 1.15 + i * 0.99;
    card(pres, s, 5.1, y, 4.4, 0.85, i % 2 ? HEX.lt2 : HEX.accent5);
    s.addText([{ text: r[0], options: { bold: true, breakLine: true, color: HEX.dk2, fontSize: 14 } }, { text: r[1], options: { fontSize: 12, color: HEX.dk1 } }],
      { x: 5.3, y, w: 4.1, h: 0.85, valign: "middle", margin: 0, isTextBox: true });
  });

  s = content(pres, "Functional requirements", "Walk through the 12 FRs; priorities show the core path first.");
  table(s, [
    ["ID", "Requirement", "Priority"],
    ["FR-01", "Register, search, update and delete customers with validation", "High"],
    ["FR-02", "Maintain service categories, services, durations and prices", "High"],
    ["FR-03", "Maintain staff, skills (with proficiency) and weekly schedules", "High"],
    ["FR-04", "Book an appointment with one or more services and time slots", "High"],
    ["FR-05", "Assign only skilled, on-shift, free staff to each service", "High"],
    ["FR-06", "Reschedule, cancel, complete or mark no-show", "High"],
    ["FR-07", "Sell packages; redeem sessions within limits and validity", "High"],
    ["FR-08", "Enrol memberships; apply plan discount on bills", "Medium"],
    ["FR-09", "Issue products against services; reduce stock; reorder alert", "Medium"],
    ["FR-10", "Generate bill (subtotal, discount, GST) for completed visits", "High"],
    ["FR-11", "Record full / partial payments without exceeding the bill", "High"],
    ["FR-12", "Reports: appointments, utilisation, popularity, packages, products, revenue", "High"],
  ], { colW: [0.8, 7.0, 1.2], fontSize: 10.5, rowH: 0.29 });

  s = content(pres, "Five business rules the database must enforce", "These rules drive the trigger design in Review 2.");
  cardGrid(pres, s, [
    { h: "No overlapping staff appointments", t: "A staff member cannot have two services whose time ranges overlap on the same day." },
    { h: "Skill match", t: "The assigned staff member must hold the skill the service requires." },
    { h: "Package-session limit", t: "Redemptions ≤ sessions included, before expiry, by the package owner." },
    { h: "Valid appointment times", t: "Inside 09:00–21:00 and the staff shift; slot length = service duration." },
    { h: "Payment limit", t: "Total paid on a bill can never exceed the bill total." },
    { h: "Supporting rules", t: "Bill only completed visits; stock never negative; unique phone and email." },
  ], { cols: 3, h: 3.9, ts: 12, hs: 13 });

  s = content(pres, "Conceptual design: ER diagram", "14 entities and 16 relationships. Weak entities have a double border; double lines are total participation.");
  s.addImage({ path: IMG("docs/er_diagram.png"), x: 0.5, y: 1.05, w: 9.0, h: 9.0 * 2212 / 5071 });

  s = content(pres, "Entities and key relationships", "Explain the main cardinalities.");
  table(s, [
    ["Relationship", "Entities", "Cardinality", "Note"],
    ["BOOKS", "Customer – Appointment", "1 : N", "a visit belongs to one customer"],
    ["INCLUDES", "Appointment – Appointment_Service", "1 : N", "one visit, many services (weak)"],
    ["PERFORMED_BY", "Appointment_Service – Staff", "N : 1", "one staff per service slot"],
    ["HAS_SKILL", "Staff – Skill", "M : N", "attribute proficiency_level"],
    ["REQUIRES", "Service – Skill", "N : 1", "basis of skill-match rule"],
    ["WORKS_ON", "Staff – Staff_Schedule", "1 : N", "weekly shifts (weak)"],
    ["CONTAINS", "Package – Service", "M : N", "attribute sessions_included"],
    ["BUYS / REDEEMS", "Customer – Customer_Package – Appt_Service", "1 : N / 1 : N", "package balance"],
    ["SUBSCRIBES", "Customer – Membership_Plan", "M : N", "start / end dates"],
    ["USES_PRODUCT", "Appointment_Service – Product", "M : N", "quantity_used"],
    ["BILLED_AS / SETTLED_BY", "Appointment – Bill – Payment", "1 : 1 / 1 : N", "partial payments allowed"],
  ], { colW: [2.0, 3.3, 1.3, 2.4], fontSize: 10.5, rowH: 0.31 });

  s = content(pres, "Initial relational schema: 18 tables", "M:N relationships become their own tables: staff_skill, package_item, customer_membership, product_usage.");
  s.addImage({ path: IMG("docs/schema_diagram.png"), x: 5.55, y: 0.95, h: 4.25, w: 4.25 * 2191 / 2464 });
  s.addText([
    { text: "Masters", options: { bold: true, color: HEX.accent1, breakLine: true } },
    { text: "customer, staff, skill, service_category, service, package, membership_plan, product", options: { breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "M:N / associative", options: { bold: true, color: HEX.accent1, breakLine: true } },
    { text: "staff_skill, package_item, customer_membership, customer_package, product_usage", options: { breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Transactions", options: { bold: true, color: HEX.accent1, breakLine: true } },
    { text: "staff_schedule, appointment, appointment_service, bill, payment", options: { breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Every table has a surrogate INT primary key (composite for the two pure link tables); 20 foreign keys connect them.", options: { italic: true } },
  ], { x: 0.5, y: 1.15, w: 4.8, h: 3.9, fontSize: 13, color: HEX.dk1, valign: "top", margin: 0, isTextBox: true });

  s = content(pres, "Plan to Review 2 and Review 3", "Timeline of remaining deliverables.");
  const steps = [["Week 7", "Review 1", "Problem, FRs, ER diagram, initial schema"], ["Weeks 8–10", "Build DB", "3NF, DDL + constraints, triggers, sample data, views"],
    ["Week 11", "Review 2", "Normalisation, data dictionary, queries & prototype"], ["Weeks 12–15", "Build app", "Python front-end, validation, testing"], ["Week 16", "Review 3", "Final demo, report, video, GitHub"]];
  steps.forEach((st, i) => {
    const x = 0.5 + i * 1.84;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 1.5, w: 1.64, h: 2.0, rectRadius: 0.1, fill: { color: i === 0 ? HEX.accent1 : HEX.lt2 }, line: { color: HEX.accent1, width: 0.75 } });
    const col = i === 0 ? "FFFFFF" : HEX.dk1;
    s.addText([{ text: st[0], options: { fontSize: 11, breakLine: true, color: i === 0 ? HEX.accent5 : HEX.accent4 } },
      { text: st[1], options: { fontSize: 16, bold: true, breakLine: true, color: col } }, { text: st[2], options: { fontSize: 12, color: col } }],
    { x: x + 0.12, y: 1.62, w: 1.4, h: 1.8, valign: "top", margin: 0, isTextBox: true });
  });

  closing(pres, "Thank you — questions?", ["Problem: manual books cause staff clashes, skill errors, lost sessions and dues",
    "Design: 14 entities, 16 relationships → 18 tables", "Next: 3NF, constraints and triggers for the five business rules"]);
  const f = path.join(__dirname, "Review1_Problem_Requirements_ER_Design.pptx");
  await pres.writeFile({ fileName: f });
  await applyTheme(f, THEME);
  return f;
}

// =====================================================================
// REVIEW 2
// =====================================================================
async function review2() {
  const pres = new pptxgen();
  const C = setup(pres, "Review 2 – Normalised Design, Constraints, Queries");
  titleSlide(pres, C, "REVIEW 2  ·  WEEK 11", META.project, "Normalised design (3NF), integrity constraints, SQL queries and prototype",
    "Review 2 shows the normalised design, data dictionary, DDL with business-rule enforcement, sample data, queries/views and the working prototype.");

  let s = content(pres, "Where the design stands", "Headline numbers of the implemented database.");
  [["18", "tables in 3NF"], ["85", "constraints (PK, FK, UNIQUE, CHECK)"], ["5", "triggers for business rules"], ["7", "views for reports"]].forEach((x, i) =>
    stat(s, 0.5 + i * 2.3, 1.3, 2.1, x[0], x[1]));
  [["603", "appointments, Aug–Oct 2026"], ["892", "booked service lines"], ["674", "product issues"], ["427", "bills · 419 payments"]].forEach((x, i) =>
    stat(s, 0.5 + i * 2.3, 2.85, 2.1, x[0], x[1], HEX.accent3));
  s.addText("DBMS: MySQL 8.0 (scripts also run unchanged on MariaDB 10.11). All sample data loads through the triggers, so every row obeys the rules.",
    { x: 0.5, y: 4.4, w: 9, h: 0.6, fontSize: 13, italic: true, color: HEX.accent4, margin: 0, isTextBox: true });

  s = content(pres, "Key functional dependencies", "Each determinant is a candidate key of its table, which is why every table is in BCNF.");
  code(s, [
    "customer_id          -> first_name, last_name, phone, email, gender, date_of_birth",
    "phone                -> customer_id                    (candidate key)",
    "service_id           -> category_id, required_skill_id, service_name, duration_min, price",
    "staff_id             -> full_name, phone, email, designation, hire_date, status",
    "{staff_id, skill_id} -> proficiency_level",
    "{staff_id, day_of_week} -> shift_start, shift_end      (candidate key)",
    "{package_id, service_id} -> sessions_included",
    "appointment_id       -> customer_id, appointment_date, status, booked_at",
    "appt_service_id      -> appointment_id, service_id, staff_id, start_time,",
    "                        end_time, price_charged, customer_package_id",
    "customer_package_id  -> customer_id, package_id, purchase_date, expiry_date",
    "bill_id              -> appointment_id, bill_date, subtotal, discount, tax",
    "appointment_id       -> bill_id                        (1:1, UNIQUE)",
    "payment_id           -> bill_id, amount, method, paid_at, reference_no",
  ].join("\n"), 0.5, 1.1, 9.0, 4.0, 11);

  s = content(pres, "Normalisation: from the paper booking slip to 3NF", "Show the unnormalised slip and how each normal form removed a problem.");
  const nf = [
    ["UNF", "Booking slip", "customer, phone, date, {service, staff, staff skills, time, price}, package, bill, payments — repeating groups"],
    ["1NF", "Atomic values", "One row per service per visit; staff skills moved to staff_skill; payments to their own rows"],
    ["2NF", "No partial deps", "service_name/price depend only on service_id; customer data only on customer_id → separate tables"],
    ["3NF", "No transitive deps", "category_name via category_id, skill_name via skill_id, plan discount via plan_id → split out"],
  ];
  nf.forEach((r, i) => {
    const y = 1.12 + i * 0.98;
    card(pres, s, 0.5, y, 9.0, 0.85, i === 3 ? HEX.accent5 : HEX.lt2);
    badge(pres, s, 0.65, y + 0.17, r[0], i === 3 ? HEX.accent6 : HEX.accent1, 0.52);
    s.addText([{ text: r[1], options: { bold: true, color: HEX.dk2, breakLine: true, fontSize: 14 } }, { text: r[2], options: { fontSize: 12, color: HEX.dk1 } }],
      { x: 1.35, y, w: 8.0, h: 0.85, valign: "middle", margin: 0, isTextBox: true });
  });

  s = content(pres, "Normalisation status of all 18 relations", "All relations reach 3NF; the stored snapshots are justified on the right.");
  table(s, [
    ["Relation(s)", "1NF", "2NF", "3NF", "BCNF", "Remark"],
    ["customer, staff, skill, service_category", "✓", "✓", "✓", "✓", "single-attribute PK; phone/email are alternate keys"],
    ["service, package, membership_plan, product", "✓", "✓", "✓", "✓", "category/skill names moved out (3NF)"],
    ["staff_skill, package_item", "✓", "✓", "✓", "✓", "composite PK; non-key depends on the whole key"],
    ["staff_schedule, customer_membership", "✓", "✓", "✓", "✓", "UNIQUE(staff_id, day_of_week) is a candidate key"],
    ["appointment, appointment_service", "✓", "✓", "✓", "✓", "price & end_time frozen at booking (history)"],
    ["customer_package", "✓", "✓", "✓", "✓", "expiry frozen at purchase (validity may change)"],
    ["product_usage", "✓", "✓", "✓", "✓", "stock kept in product, updated by trigger"],
    ["bill, payment", "✓", "✓", "✓", "✓", "total is a generated column; paid/balance computed in a view"],
  ], { colW: [3.0, 0.5, 0.5, 0.5, 0.6, 3.9], fontSize: 10.5, rowH: 0.42 });

  s = content(pres, "Data dictionary extract: appointment_service", "Full dictionary for all tables is in the report (Table 8).");
  table(s, [
    ["Attribute", "Type", "Key / constraint", "Description"],
    ["appt_service_id", "INT", "PK, AUTO_INCREMENT", "one booked service inside a visit"],
    ["appointment_id", "INT", "FK → appointment, NOT NULL, CASCADE", "the visit"],
    ["service_id", "INT", "FK → service, NOT NULL", "service performed"],
    ["staff_id", "INT", "FK → staff, NOT NULL", "staff member assigned"],
    ["start_time / end_time", "TIME", "CHECK end > start; 09:00–21:00", "slot; length = service duration (trigger)"],
    ["price_charged", "DECIMAL(8,2)", "CHECK ≥ 0", "price at booking; 0 when from package"],
    ["customer_package_id", "INT", "FK → customer_package, NULL, SET NULL", "package redeemed, if any"],
  ], { colW: [2.0, 1.3, 2.9, 2.8], fontSize: 11, rowH: 0.42 });

  s = content(pres, "Integrity constraints in the DDL", "Declarative constraints first; triggers only where a rule needs other rows.");
  const cons = [["18", "PRIMARY KEY"], ["20", "FOREIGN KEY (RESTRICT / CASCADE / SET NULL)"], ["12", "UNIQUE"], ["35", "CHECK"], ["17", "DEFAULT"], ["88", "NOT NULL columns"]];
  cons.forEach((c, i) => {
    const x = 0.5 + (i % 3) * 1.6, y = 1.2 + Math.floor(i / 3) * 1.35;
    s.addText(c[0], { x, y, w: 1.5, h: 0.6, fontSize: 30, bold: true, color: HEX.accent1, fontFace: "Cambria", margin: 0, isTextBox: true });
    s.addText(c[1], { x, y: y + 0.6, w: 1.5, h: 0.6, fontSize: 11, color: HEX.accent4, valign: "top", margin: 0, isTextBox: true });
  });
  code(s, [
    "CONSTRAINT chk_customer_phone",
    "  CHECK (phone REGEXP '^[6-9][0-9]{9}$'),",
    "CONSTRAINT chk_as_hours CHECK",
    "  (start_time >= '09:00:00'",
    "   AND end_time <= '21:00:00'),",
    "CONSTRAINT chk_bill_discount CHECK",
    "  (discount_amount <= subtotal),",
    "total_amount DECIMAL(10,2) AS",
    "  (subtotal - discount_amount",
    "   + tax_amount) STORED,",
    "CONSTRAINT uq_sched_staff_day",
    "  UNIQUE (staff_id, day_of_week)",
  ].join("\n"), 5.4, 1.15, 4.1, 3.9, 10.5);

  s = content(pres, "Business rules enforced inside MySQL", "Triggers raise SQLSTATE 45000 with a readable message; the app shows it as is.");
  table(s, [
    ["Rule", "Mechanism", "Error raised on violation"],
    ["No overlapping staff appointments", "trigger: startA < endB AND startB < endA on same staff/date", "Staff conflict: … overlapping appointment"],
    ["Skill match", "trigger: staff_skill must contain service.required_skill_id", "Skill mismatch: …"],
    ["Valid appointment times", "CHECK 09:00–21:00 + trigger: slot = duration, inside shift", "Invalid time slot / not on shift"],
    ["Package-session limit", "trigger: owner, ACTIVE, not expired, used < sessions_included", "Package session limit reached"],
    ["Payment limit", "trigger: SUM(paid) + new ≤ bill.total_amount", "Payment exceeds balance …"],
    ["Stock never negative", "trigger on product_usage + CHECK stock_qty ≥ 0", "Insufficient stock …"],
    ["Bill only completed visits", "trigger on bill", "Bill can be generated only for …"],
  ], { colW: [2.3, 4.0, 2.7], fontSize: 10.5, rowH: 0.45 });

  s = content(pres, "The overlap rule, in SQL", "Same check runs on INSERT and UPDATE via one stored procedure.");
  code(s, [
    "-- inside sp_validate_appt_service (called by BEFORE INSERT / UPDATE triggers)",
    "SELECT COUNT(*) INTO v_cnt",
    "  FROM appointment_service s",
    "  JOIN appointment a ON a.appointment_id = s.appointment_id",
    " WHERE s.staff_id = p_staff_id",
    "   AND a.appointment_date = v_date",
    "   AND a.status NOT IN ('CANCELLED','NO_SHOW')",
    "   AND s.appt_service_id <> p_self_id        -- ignore the row being updated",
    "   AND s.start_time < p_end AND p_start < s.end_time;   -- interval overlap",
    "IF v_cnt > 0 THEN",
    "   SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =",
    "      'Staff conflict: staff member already has an overlapping appointment';",
    "END IF;",
  ].join("\n"), 0.5, 1.1, 9.0, 3.4, 11);
  s.addText("Back-to-back slots (10:00–11:00 then 11:00–12:00) are allowed; cancelled visits free their slots automatically.",
    { x: 0.5, y: 4.6, w: 9, h: 0.5, fontSize: 13, italic: true, color: HEX.accent4, margin: 0, isTextBox: true });

  s = content(pres, "Sample data: a realistic salon, Aug–Oct 2026", "Generated by a seeded Python script, loaded through the triggers.");
  s.addChart(pres.charts.BAR, [{ name: "Rows", labels: ["service", "staff_skill", "customer", "staff_schedule", "payment", "bill", "appointment", "product_usage", "appointment_service"], values: [22, 23, 40, 60, 419, 427, 603, 674, 892] }],
    Object.assign(chartBase(), { x: 0.5, y: 1.05, w: 5.4, h: 4.1, barDir: "bar", chartColors: [HEX.accent1], showValue: true, dataLabelPosition: "outEnd", showLegend: false,
      showTitle: true, title: "Rows per table (largest 9)" }));
  s.addText([
    { text: "40 customers, 10 staff (1 on leave), 22 services in 6 categories, 10 skills", options: { bullet: true, breakLine: true } },
    { text: "6 packages, 3 membership plans, 15 products with stock", options: { bullet: true, breakLine: true } },
    { text: "603 visits: 427 completed, 125 upcoming, 41 cancelled, 10 no-show", options: { bullet: true, breakLine: true } },
    { text: "10 bills deliberately left part-paid to test balances", options: { bullet: true } },
  ], { x: 6.1, y: 1.2, w: 3.4, h: 3.8, fontSize: 13, color: HEX.dk1, valign: "top", paraSpaceAfter: 8, margin: 0, isTextBox: true });

  s = content(pres, "Queries and views", "20 queries in 05_queries.sql cover every SQL concept asked for.");
  table(s, [
    ["Report area", "View", "SQL concepts demonstrated"],
    ["Appointments", "v_appointment_details", "5-table JOIN, LEFT JOIN … IS NULL, correlated subquery"],
    ["Staff utilisation", "v_staff_utilization", "derived tables, CROSS JOIN, SUM/COUNT, HAVING, EXISTS / NOT EXISTS"],
    ["Service popularity", "v_service_popularity", "LEFT JOIN, IN subquery, GROUP BY, revenue share via scalar subquery"],
    ["Package balances", "v_package_balance", "correlated subquery for sessions used, date filter"],
    ["Product use", "v_product_usage", "aggregation, CASE for re-order flag, cost per service"],
    ["Revenue", "v_monthly_revenue, v_bill_summary", "GROUP BY month, billed vs collected, above-average spenders"],
  ], { colW: [1.9, 2.6, 4.5], fontSize: 11, rowH: 0.5 });

  s = content(pres, "What the reports show", "Two of the six reports, plotted from the views.");
  s.addChart(pres.charts.BAR, [{ name: "Utilisation %", labels: ["Arjun R.", "Irfan M.", "Sneha K.", "Kavya S.", "Fatima B.", "Priya N.", "Ananya R.", "Lakshmi P.", "Rohan V."], values: [4.4, 7.2, 9.1, 9.2, 10.2, 10.2, 12.7, 16.1, 21.2] }],
    Object.assign(chartBase(), { x: 0.5, y: 1.05, w: 4.4, h: 4.1, barDir: "bar", chartColors: [HEX.accent1], showValue: true, dataLabelPosition: "outEnd", showLegend: false, showTitle: true, title: "Staff utilisation % (completed work ÷ shift time)", valAxisMaxVal: 25 }));
  s.addChart(pres.charts.BAR, [{ name: "Billed ₹", labels: ["Aug", "Sep", "Oct (to 7th)"], values: [306293, 401262, 96968] }, { name: "Collected ₹", labels: ["Aug", "Sep", "Oct (to 7th)"], values: [306293, 396335, 93394] }],
    Object.assign(chartBase(), { x: 5.1, y: 1.05, w: 4.4, h: 4.1, barDir: "col", chartColors: [HEX.accent1, HEX.accent2], showLegend: true, legendPos: "b", legendFontFace: "+mn-lt", legendFontSize: 10, showTitle: true, title: "Monthly revenue (₹)", valAxisLabelFormatCode: "#,##0" }));

  s = content(pres, "Testing the rules: 18 cases, all behave as expected", "Script 06 runs in one transaction and rolls back.");
  table(s, [
    ["Test", "Action", "Result"],
    ["TC-01 / 03", "Valid booking; back-to-back booking", "Inserted ✓"],
    ["TC-02", "Same staff, overlapping 13:30–14:30", "Rejected: Staff conflict ✓"],
    ["TC-04", "Bridal makeup given to the barber", "Rejected: Skill mismatch ✓"],
    ["TC-05 / 06 / 07", "45 min for a 30 min service; before shift; 08:00", "Rejected: invalid time ✓"],
    ["TC-08 / 10", "Someone else's package; 5th of 4 sessions", "Rejected ✓"],
    ["TC-11 / 12", "Bill a booked visit; pay more than balance", "Rejected ✓"],
    ["TC-14 – 18", "Over-issue stock, bad phone, duplicate phone, delete referenced customer, discount > subtotal", "Rejected ✓"],
  ], { colW: [1.6, 5.2, 2.2], fontSize: 11, rowH: 0.47 });

  s = content(pres, "Prototype: database connected to the Python app", "Show the live dashboard; the app is the Review 3 deliverable.");
  shot(pres, s, "01_dashboard.png", 0.5, 1.1, 6.3, 4.0);
  s.addText([{ text: "Already working", options: { bold: true, color: HEX.accent1, breakLine: true } },
    { text: "Dashboard, booking with skilled-staff filter, billing and reports on the live database", options: { breakLine: true } },
    { text: " ", options: { breakLine: true, fontSize: 6 } },
    { text: "Next (Review 3)", options: { bold: true, color: HEX.accent1, breakLine: true } },
    { text: "Full CRUD, validation messages, test log, report and video" }],
  { x: 7.1, y: 1.15, w: 2.4, h: 3.9, fontSize: 13, color: HEX.dk1, valign: "top", margin: 0, isTextBox: true });

  closing(pres, "Thank you — questions?", ["18 tables in 3NF/BCNF with 85 declarative constraints", "5 triggers enforce overlap, skill, time, package and payment rules",
    "7 views and 20 queries cover the six required reports", "Next: complete the application, testing and documentation"]);
  const f = path.join(__dirname, "Review2_Normalisation_Constraints_Queries.pptx");
  await pres.writeFile({ fileName: f });
  await applyTheme(f, THEME);
  return f;
}

// =====================================================================
// REVIEW 3
// =====================================================================
async function review3() {
  const pres = new pptxgen();
  const C = setup(pres, "Review 3 – Application, Testing and Final Demo");
  titleSlide(pres, C, "REVIEW 3  ·  WEEK 16  ·  FINAL", META.project, "Python application on the designed database: demonstration, testing and results",
    "Final review: the working application, how it uses the database, validation, reports, tests and conclusions.");

  let s = content(pres, "Architecture: the rules live in the database", "Even a bad client cannot break the rules: triggers sit below the app.");
  const layers = [["Presentation", "Streamlit (Python) — 9 screens: dashboard, customers, booking, appointments, packages, products, billing, staff, reports", HEX.accent2],
    ["Data access", "db.py — mysql-connector-python, parameterised queries, transaction() with COMMIT / ROLLBACK, friendly error mapping", HEX.accent1],
    ["Database", "MySQL 8 — 18 tables, 85 constraints, 5 triggers + 1 procedure, 7 views, 7 secondary indexes", HEX.dk2]];
  layers.forEach((l, i) => {
    const y = 1.15 + i * 1.3;
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.5, y, w: 9.0, h: 1.1, rectRadius: 0.1, fill: { color: l[2] }, line: { color: l[2], width: 0 } });
    s.addText([{ text: l[0], options: { bold: true, fontSize: 17, breakLine: true } }, { text: l[1], options: { fontSize: 13 } }],
      { x: 0.75, y, w: 8.5, h: 1.1, color: "FFFFFF", valign: "middle", margin: 0, isTextBox: true });
  });

  s = content(pres, "Development environment", "Everything is open source and runs on a laptop.");
  table(s, [
    ["Item", "Details"],
    ["Language", "Python 3.11+"],
    ["DBMS", "MySQL 8.0 (also verified on MariaDB 10.11)"],
    ["GUI framework", "Streamlit (browser-based UI written in pure Python)"],
    ["Driver", "mysql-connector-python (official Oracle connector)"],
    ["Tools", "VS Code, MySQL Workbench / mysql CLI, Git & GitHub"],
    ["Run", "mysql -u root -p < database/salon_spa_full.sql  →  streamlit run app/streamlit_app.py"],
  ], { colW: [2.2, 6.8], fontSize: 13, rowH: 0.52 });

  s = content(pres, "Modules mapped to tables", "Every screen reads and writes the designed tables; no static data.");
  table(s, [
    ["Module", "Main tables", "Operations"],
    ["Customers", "customer, customer_membership", "Create, search, update, delete (FK-guarded)"],
    ["Book Appointment", "appointment, appointment_service, staff_skill, staff_schedule, customer_package", "Insert in one transaction; skilled-free staff list"],
    ["Manage Appointments", "appointment, appointment_service", "Complete / cancel / no-show, reschedule (trigger re-check)"],
    ["Packages & Memberships", "package, package_item, customer_package, membership_plan", "Sell, enrol, balances (view)"],
    ["Products & Stock", "product, product_usage", "Issue (stock trigger), restock, add"],
    ["Billing & Payments", "bill, payment, v_bill_summary", "Generate bill with discount + GST; part payments"],
    ["Reports", "7 views", "6 reports, charts, CSV export"],
  ], { colW: [2.0, 4.0, 3.0], fontSize: 11, rowH: 0.5 });

  s = content(pres, "Booking: only skilled, free staff are offered", "Demo: pick customer, service, time; the staff list is filtered by skill, shift and clashes.");
  shot(pres, s, "05_booking_skilled_staff.png", 0.5, 1.1, 4.6, 4.0);
  shot(pres, s, "07_booking_confirmed.png", 5.4, 1.1, 4.1, 3.1);
  s.addText("Header + all service lines are inserted in one transaction: all or nothing.", { x: 5.4, y: 4.4, w: 4.1, h: 0.7, fontSize: 13, color: HEX.dk1, valign: "top", margin: 0, isTextBox: true });

  s = content(pres, "Validation and error handling", "Two layers: Python checks input format; MySQL enforces business rules.");
  const shots = [["screenshots/02_register_validation.png", "Input validation (Python)"], ["screenshots/08_booking_rejected_skill.png", "Skill mismatch (trigger)"],
    ["screenshots/13_payment_over_limit.png", "Over-payment (trigger)"], ["screenshots/17_product_insufficient.png", "Insufficient stock (trigger)"]];
  shots.forEach((sh, i) => {
    const x = 0.5 + (i % 2) * 4.6, y = 1.05 + Math.floor(i / 2) * 2.05;
    s.addText(sh[1], { x, y, w: 4.4, h: 0.3, fontSize: 13, bold: true, color: HEX.accent1, margin: 0, isTextBox: true });
    shot(pres, s, sh[0].replace("screenshots/", ""), x, y + 0.35, 4.4, 1.6);
  });

  s = content(pres, "Billing and payments", "Bill = subtotal − membership discount + 18% GST; payments may be split.");
  shot(pres, s, "31_member_discount_bill.png", 0.5, 1.1, 4.4, 3.2);
  shot(pres, s, "15_bill_view.png", 5.1, 1.1, 4.4, 3.2);
  s.addText("Gold member: 10% off, then 18% GST · only COMPLETED visits can be billed (trigger) · total is a generated column · balance and status come from v_bill_summary",
    { x: 0.5, y: 4.45, w: 9, h: 0.65, fontSize: 12, color: HEX.dk1, margin: 0, isTextBox: true });

  s = content(pres, "Reports", "Six reports, each from a view, with CSV export.");
  shot(pres, s, "23_report_staff_utilisation.png", 0.5, 1.1, 4.4, 3.4);
  shot(pres, s, "27_report_revenue.png", 5.1, 1.1, 4.4, 3.4);
  s.addText("Appointments · Staff utilisation · Service popularity · Package balances · Product use · Revenue",
    { x: 0.5, y: 4.65, w: 9, h: 0.45, fontSize: 13, color: HEX.accent1, bold: true, margin: 0, isTextBox: true });

  s = content(pres, "CRUD, transactions and indexing", "How the app satisfies the 'transaction awareness' and 'indexing' requirements.");
  cardGrid(pres, s, [
    { h: "CRUD", t: "Create customer / booking / bill / payment; read via search and views; update profile, status, schedule, price, stock; controlled delete with FK RESTRICT." },
    { h: "Transactions", t: "Booking writes header + lines in START TRANSACTION … COMMIT; any trigger error rolls back everything. SELECT … FOR UPDATE in stock and payment triggers." },
    { h: "Indexing", t: "7 secondary indexes on searched columns: customer name, appointment date+status, staff+start time, bill date, payment time, package status." },
    { h: "Security", t: "All SQL uses %s parameters (no string building), so user input cannot inject SQL. DB user with least privilege." },
  ], { cols: 2, h: 3.9, ts: 12, hs: 15 });

  s = content(pres, "Test results", "Application-level tests, positive and negative.");
  table(s, [
    ["ID", "Feature", "Input / action", "Expected", "Status"],
    ["TC-01", "Register customer", "Phone 12345, email 'x@gmail'", "Two validation errors", "Pass"],
    ["TC-02", "Register customer", "Valid details", "Saved, new ID shown", "Pass"],
    ["TC-03", "Booking", "Facial 17:00 + threading 18:00", "Only skilled free staff; booked", "Pass"],
    ["TC-04", "Booking", "Party makeup → barber (filter off)", "Rejected, rolled back", "Pass"],
    ["TC-05", "Reschedule", "Threading moved onto a facial slot", "Staff conflict message", "Pass"],
    ["TC-06", "Package", "Manicure, 3 of 4 sessions used", "Redeemed at ₹0", "Pass"],
    ["TC-07", "Billing", "₹600 haircut, Gold member", "₹60 off + GST = ₹637.20", "Pass"],
    ["TC-08", "Payment", "₹5,000 on ₹1,746.40 bill", "Exceeds balance error", "Pass"],
    ["TC-09", "Product issue", "500 facial kits", "Insufficient stock error", "Pass"],
    ["TC-10", "Delete customer", "Customer with history", "FK blocks deletion", "Pass"],
  ], { colW: [0.7, 1.6, 2.9, 2.9, 0.9], fontSize: 10.5, rowH: 0.36 });

  s = content(pres, "Conclusion, limitations and next steps", "Wrap up.");
  card(pres, s, 0.5, 1.15, 4.35, 3.9, HEX.accent5);
  s.addText([{ text: "Delivered", options: { bold: true, fontSize: 16, color: HEX.dk2, breakLine: true } },
    { text: "3NF database where the five salon rules cannot be broken by any client", options: { bullet: true, breakLine: true } },
    { text: "Python app covering booking to payment, plus six reports", options: { bullet: true, breakLine: true } },
    { text: "Repeatable test script and realistic data", options: { bullet: true } }],
  { x: 0.7, y: 1.3, w: 4.0, h: 3.6, fontSize: 13, color: HEX.dk1, valign: "top", paraSpaceAfter: 6, margin: 0, isTextBox: true });
  card(pres, s, 5.15, 1.15, 4.35, 3.9);
  s.addText([{ text: "Limitations → future", options: { bold: true, fontSize: 16, color: HEX.dk2, breakLine: true } },
    { text: "No login/roles yet → add role-based access", options: { bullet: true, breakLine: true } },
    { text: "Single branch → branch_id on staff and appointments", options: { bullet: true, breakLine: true } },
    { text: "No reminders → SMS / WhatsApp before appointment", options: { bullet: true, breakLine: true } },
    { text: "Customer self-booking portal", options: { bullet: true } }],
  { x: 5.35, y: 1.3, w: 4.0, h: 3.6, fontSize: 13, color: HEX.dk1, valign: "top", paraSpaceAfter: 6, margin: 0, isTextBox: true });

  closing(pres, "Thank you", ["GitHub repository: <add your repo link>", "5-minute demo video: <add your Google Drive link>",
    "Repository contains: 3 review decks, SQL scripts, app source, test data, screenshots, report"],
  "Replace the two placeholders with the real links before presenting.");
  const f = path.join(__dirname, "Review3_Application_Final_Demo.pptx");
  await pres.writeFile({ fileName: f });
  await applyTheme(f, THEME);
  return f;
}

(async () => {
  for (const fn of [review1, review2, review3]) console.log(await fn());
})();
