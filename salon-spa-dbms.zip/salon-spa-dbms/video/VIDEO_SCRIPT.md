# 5-minute demo video — recording script

Record your screen (OBS Studio or SimpleScreenRecorder on Arch) at 1920×1080 with the app open in the browser.
Before recording: run `mysql -u root -p < database/salon_spa_full.sql` so the data is clean, then `streamlit run app/streamlit_app.py`.
Keep the Review 3 deck open in another window for the first and last 30 seconds.

| Time | Show | Say (roughly) |
|---|---|---|
| 0:00–0:30 | Review 3 title slide, then the architecture slide | "I'm Devyani Pawar, 25WU0102069. My project is a Salon and Spa Appointment Management System — a MySQL database in 3NF with a Python Streamlit front end. The key idea: the five salon rules live inside the database as constraints and triggers." |
| 0:30–0:50 | ER diagram slide | "14 entities and 16 relationships became 18 tables. Staff and skills are many-to-many, packages contain services, and every booked service links a visit, a service and a staff member." |
| 0:50–1:20 | **Dashboard** | "This is the live dashboard for 8 October: today's schedule, revenue this month, outstanding dues and the product that needs re-ordering — all read from views." |
| 1:20–1:50 | **Customers → Register**: type phone `12345`, email `abc@gmail`, submit; then a valid customer | "Input is validated first in Python… and with valid details the customer is saved." |
| 1:50–2:40 | **Book Appointment**: pick the new customer, Classic Facial at 5:00 PM, show the staff list, add; add Eyebrow Threading 6:00 PM; Confirm | "Only staff who have the facial skill, are on shift and are free are offered. Both services are saved in one transaction." |
| 2:40–3:10 | Same page: Party Makeup 7:00 PM, switch off *Show only available skilled staff*, choose Arjun Rao (barber), Confirm | "If I bypass the filter and give makeup to the barber, MySQL's trigger rejects it and the whole booking is rolled back." |
| 3:10–3:30 | **Manage Appointments**: search the customer, *Mark completed*; then reschedule another booking onto a busy slot | "Completing a visit; and a reschedule onto a busy slot is refused with 'Staff conflict'." |
| 3:30–4:05 | **Billing**: generate the bill; **Record payment**: enter 5000 → error; enter 1000 → saved; View bill shows PARTIAL | "Bill = subtotal minus membership discount plus 18% GST. Paying more than the balance is blocked by the payment-limit trigger; part payments are allowed." |
| 4:05–4:25 | **Packages → balances**; **Products → Issue** 500 kits → error | "Package sessions used and left come from a view; issuing more stock than available is blocked." |
| 4:25–4:50 | **Reports**: staff utilisation, service popularity, revenue; click *Download CSV* | "Six reports — appointments, staff utilisation, service popularity, package balances, product use and revenue — each backed by a SQL view." |
| 4:50–5:00 | Thank-you slide | "All code, SQL scripts, test data, the three review decks and the report are in my GitHub repository. Thank you." |

## After recording

1. Upload the video to your personal Google Drive.
2. Right-click → Share → General access: **Anyone with the link** → Viewer → Copy link.
3. Paste the link into `video/VIDEO_LINK.md` (and the last slide of the Review 3 deck), commit and push.
